# Chess Assistant Overlay v2

Android Studio / AndroidIDE starter project. It provides a draggable floating menu with:
- Elo-style practice rating presets from 400 to 3000
- Broad player-inspired study profiles for Magnus Carlsen, Bobby Fischer, and Hikaru Nakamura
- Assistant, Styles, and Position tabs
- FEN format plausibility check
- Overlay permission and foreground service

## Important
This version is a menu/UI prototype. It does not yet include Stockfish, legal position parsing, automatic board recognition, or generated best-move arrows. The Elo and style settings are preferences only until a chess engine is integrated. Use position review for study and completed games, not move assistance during live rated games.

## Build
Open the project in Android Studio or a compatible Android Gradle environment and build `:app:assembleDebug`. The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
