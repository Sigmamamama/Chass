plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.carter.chessoverlay"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.carter.chessoverlay"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
