package com.carter.chessoverlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private val channelId = "chess_assistant_channel"

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Chess Assistant",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId) else Notification.Builder(this)
        startForeground(7, builder.setContentTitle("Chess Assistant")
            .setContentText("Floating study menu is active")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build())
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(13, 11, 13, 13)
            setBackgroundColor(Color.rgb(15, 15, 15))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "♟ CHESS ASSISTANT"
            textSize = 16f
            setTextColor(Color.rgb(255, 75, 75))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val minimize = Button(this).apply { text = "—"; setOnClickListener {
            val v = panel ?: return@setOnClickListener
            v.visibility = if (v.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        } }
        val close = Button(this).apply { text = "×"; setOnClickListener { stopSelf() } }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(minimize)
        header.addView(close)
        root.addView(header)

        val disclaimer = TextView(this).apply {
            text = "STUDY / POST-GAME REVIEW • Not for live rated-game move assistance"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(0, 3, 0, 9)
        }
        root.addView(disclaimer)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 8, 0, 0)
        }
        root.addView(tabs)
        root.addView(content)

        fun label(text: String): TextView = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 9, 0, 3)
        }
        fun heading(text: String): TextView = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        }
        fun spinner(items: List<String>): Spinner {
            val s = Spinner(this)
            s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
            return s
        }
        fun addTab(name: String, page: () -> Unit) {
            tabs.addView(Button(this).apply {
                text = name
                textSize = 11f
                setOnClickListener { content.removeAllViews(); page() }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }

        val eloItems = listOf("Beginner · 400", "600", "800", "1,000", "1,200",
            "1,400", "1,600", "1,800", "2,000", "2,200", "2,400", "2,600", "2,800", "3,000")
        val styleItems = listOf(
            "Balanced",
            "Magnus Carlsen-inspired · flexible, positional",
            "Bobby Fischer-inspired · principled, direct",
            "Hikaru Nakamura-inspired · tactical, dynamic",
            "Attacking · seek initiative",
            "Positional · improve piece placement",
            "Defensive · prioritize king safety"
        )

        fun assistantPage() {
            content.addView(heading("POSITION ASSISTANT"))
            content.addView(label("Study strength / target rating"))
            val elo = spinner(eloItems); content.addView(elo)
            content.addView(label("Practice style"))
            val style = spinner(styleItems); content.addView(style)
            content.addView(label("Move arrows"))
            val arrowInfo = TextView(this).apply {
                text = "Move arrows will appear here when a chess position is analyzed by an engine."
                textSize = 12f
                setTextColor(Color.WHITE)
                setPadding(10, 12, 10, 12)
                setBackgroundColor(Color.rgb(35, 25, 25))
            }
            content.addView(arrowInfo)
            content.addView(Button(this).apply {
                text = "Save practice settings"
                setOnClickListener {
                    arrowInfo.text = "Saved: ${elo.selectedItem} • ${style.selectedItem}\nThese are practice preferences; engine move arrows are not connected in this build."
                }
            })
        }
        fun stylePage() {
            content.addView(heading("PLAYER-INSPIRED STYLES"))
            content.addView(TextView(this).apply {
                text = "Choose broad training characteristics, not an exact replica of any player's decisions."
                textSize = 12f; setTextColor(Color.LTGRAY)
            })
            val descriptions = listOf(
                "Magnus Carlsen" to "Flexible plans, endgame technique, persistent pressure.",
                "Bobby Fischer" to "Classical opening principles, active pieces, direct calculation.",
                "Hikaru Nakamura" to "Dynamic positions, tactical alertness, practical complications."
            )
            descriptions.forEach { (name, desc) ->
                content.addView(heading(name))
                content.addView(TextView(this).apply {
                    text = desc; textSize = 12f; setTextColor(Color.LTGRAY)
                })
            }
            content.addView(label("These are descriptive study presets, not licensed player profiles or exact playing replicas."))
        }
        fun positionPage() {
            content.addView(heading("POSITION REVIEW"))
            content.addView(label("Paste a FEN from a study or completed game"))
            val fen = EditText(this).apply {
                hint = "FEN position"
                textSize = 11f
                setTextColor(Color.WHITE)
                setHintTextColor(Color.GRAY)
                minLines = 2
                setBackgroundColor(Color.rgb(38, 38, 38))
            }
            content.addView(fen)
            val result = TextView(this).apply {
                text = "No position loaded."
                textSize = 12f
                setTextColor(Color.LTGRAY)
                setPadding(0, 8, 0, 8)
            }
            content.addView(result)
            content.addView(Button(this).apply {
                text = "Check FEN format"
                setOnClickListener {
                    val parts = fen.text.toString().trim().split(Regex("\\s+"))
                    val plausible = parts.size == 6 && parts[0].count { it == '/' } == 7 &&
                        (parts[1] == "w" || parts[1] == "b")
                    result.text = if (plausible)
                        "FEN structure looks plausible. Full chess legality and engine analysis are not yet implemented."
                    else "Invalid or incomplete FEN. A FEN contains six space-separated fields."
                }
            })
        }

        addTab("Assistant") { assistantPage() }
        addTab("Styles") { stylePage() }
        addTab("Position") { positionPage() }
        assistantPage()

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 18; y = 140
        }

        var initialX = 0; var initialY = 0
        var touchX = 0f; var touchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchX = event.rawX; touchY = event.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX-touchX).toInt()
                    params.y = initialY + (event.rawY-touchY).toInt()
                    wm.updateViewLayout(root, params); true
                }
                else -> false
            }
        }
        panel = root
        wm.addView(root, params)
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
